# ZombieBird
LibGDX Zombie Bird Tutorial Final Output with code based on Day 12 off Zombie Bird

Updated configuration of gradle and dependent libraries to work with later versions of Android Studio

![Zombie Bird Image](http://i.imgur.com/F36XNxj.png)
